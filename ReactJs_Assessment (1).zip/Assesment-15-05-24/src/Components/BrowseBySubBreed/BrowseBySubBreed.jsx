import React, { useState, useEffect } from "react";
import SideBar from "../SideBar/SideBar";
import "./BrowseBySubBreed.css";

const BrowseBySubBreed = () => {
  const [breed, setBreed] = useState("");
  const [subBreed, setSubBreed] = useState("");
  const [breeds, setBreeds] = useState([]);
  const [subBreeds, setSubBreeds] = useState([]);
  const [images, setImages] = useState([]);

  useEffect(() => {
    // Fetch the list of breeds when the component mounts
    fetch("https://dog.ceo/api/breeds/list/all")
      .then((response) => response.json())
      .then((data) => setBreeds(Object.keys(data.message)))
      .catch((error) => console.error("Error fetching data:", error));
  }, []);

  useEffect(() => {
    // Fetch the list of sub-breeds whenever the breed changes
    if (breed !== "") {
      fetch(`https://dog.ceo/api/breed/${breed}/list`)
        .then((response) => response.json())
        .then((data) => setSubBreeds(data.message))
        .catch((error) => console.error("Error fetching data:", error));
    }
  }, [breed]);

  useEffect(() => {
    // Fetch the images whenever the sub-breed changes
    if (breed !== "" && subBreed !== "") {
      fetch(`https://dog.ceo/api/breed/${breed}/${subBreed}/images`)
        .then((response) => response.json())
        .then((data) => setImages(data.message.slice(0, 10)))
        .catch((error) => console.error("Error fetching data:", error));
    }
  }, [breed, subBreed]);

  const handleBreedChange = (e) => {
    setBreed(e.target.value);
  };

  const handleSubBreedChange = (e) => {
    setSubBreed(e.target.value);
  };

  const renderImages = () => {
    return (
      <div className="grid-container">
        {images.map((image, index) => (
          <img key={index} src={image} alt={subBreed} className="dog-image" />
        ))}
      </div>
    );
  };

  return (
    <>
      <div className="app-container">
        <SideBar />
        <div className="browse-by-sub-breed-container">
          <h2>Browse by Sub-Breed</h2>
          <form>
            <label htmlFor="breed">Select a breed:</label>
            <select
              id="breed"
              name="breed"
              value={breed}
              onChange={handleBreedChange}
            >
              <option value="">-- Please select --</option>
              {breeds.map((breed, index) => (
                <option key={index} value={breed}>
                  {breed}
                </option>
              ))}
            </select>
            {breed && (
              <>
                <label htmlFor="subBreed">Select a sub-breed:</label>
                <select
                  id="subBreed"
                  name="subBreed"
                  value={subBreed}
                  onChange={handleSubBreedChange}
                >
                  <option value="">-- Please select --</option>
                  {subBreeds.map((subBreed, index) => (
                    <option key={index} value={subBreed}>
                      {subBreed}
                    </option>
                  ))}
                </select>
              </>
            )}
          </form>
          {subBreed && renderImages()}
        </div>
      </div>
    </>
  );
};

export default BrowseBySubBreed;
