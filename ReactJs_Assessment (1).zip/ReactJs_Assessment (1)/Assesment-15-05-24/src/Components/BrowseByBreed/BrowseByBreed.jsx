import React, { useState, useEffect } from "react";
import SideBar from "../SideBar/SideBar";
import "./BrowseByBreed.css";

const BrowseByBreed = () => {
  const [breed, setBreed] = useState("");
  const [images, setImages] = useState([]);

  useEffect(() => {
    if (breed !== "") {
      fetch(`https://dog.ceo/api/breed/${breed}/images`)
        .then((response) => response.json())
        .then((data) => setImages(data.message.slice(0, 10)))
        .catch((error) => console.error("Error fetching data:", error));
    }
  }, [breed]);

  const handleBreedChange = (e) => {
    setBreed(e.target.value);
  };

  const renderImages = () => {
    return (
      <div className="grid-container">
        {images.map((image, index) => (
          <img key={index} src={image} alt={breed} className="dog-image" />
        ))}
      </div>
    );
  };
  return (
    <>
      <div className="app-container">
        <SideBar />
        <div className="browse-by-category-container">
            <br />
            <br />
          <h2 className="browse">Browse By Breed</h2>
          <form>
            <label htmlFor="breed">Select a Breed:</label>
            <select
              id="breed"
              name="breed"
              value={breed}
              onChange={handleBreedChange}
            >
              <option value="">-- Please select --</option>
              <option value="affenpinscher">Affenpinscher</option>
              <option value="african">African</option>
              <option value="airedale">Airedale</option>
              <option value="akita">Akita</option>
              {/* Add more breeds as needed */}
            </select>
          </form>
          {breed && renderImages()}
        </div>
      </div>
    </>
  );
};

export default BrowseByBreed;
