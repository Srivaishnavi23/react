// Import the necessary dependencies
import React from 'react';
//import Logo from '../SideBar/dog-api-logo.png'

 // Assuming that the Logo component is defined in a separate file
import './SideBar.css';
 
// Define the Sidebar component
const SideBar = () => {
    return (
      <div className="sidebar">
        <img src={"https://th.bing.com/th/id/OIP.SNirRe4vkN2sbaDvIoxlPQHaHa?w=193&h=193&c=7&r=0&o=5&pid=1.7"} alt="Logo" />
     
   
 
      {/* Include the components */}
      <div className="components">
        <a href="/api">Documentation</a>
        <a href="/breeds">Breeds list</a>
        <a href="/about">About</a>
        <a href="/submit">Submit your dog</a>
        <a href="/ceo">Dog CEO Zine</a>
        <a href="/treat">$ Buy me a dog treat</a>
        <a href="/github">View on GitHub</a>
        <a href="/twitter">Follow on Twitter</a>
      </div>
    </div>
  );
};
 
// Export the Sidebar component
export default SideBar;