import React from 'react'
import ReactDOM from 'react-dom/client'
import { RouterProvider,createBrowserRouter } from 'react-router-dom';
import App from './App.jsx'
import BrowseByBreed from './Components/BrowseByBreed/BrowseByBreed.jsx';
import BrowseBySubBreed from './Components/BrowseBySubBreed/BrowseBySubBreed.jsx';
import SideBar from './Components/SideBar/SideBar.jsx';
import './index.css'

const route = createBrowserRouter([{
  path: '/',
  element: <BrowseByBreed />
},
{
  path: '/Breed',
  element: <BrowseBySubBreed />
}

])

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(
  <React.StrictMode>
    <RouterProvider router={route} />
  </React.StrictMode>
);
